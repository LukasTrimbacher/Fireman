module mySpinner {
}